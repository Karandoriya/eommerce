from django.shortcuts import render,redirect
from django.views import View
from .forms import *
from .models import *
import razorpay
from django.conf import settings
from django.contrib import messages
from django.shortcuts import get_object_or_404
from django.http import JsonResponse
# Create your views here.
def home(request):
    return render(request, 'app/home.html')

def shop_all(request):
    return render(request, 'app/shop.html') 


def contact_us (request):
    return render(request,"app/contact.html")

class CustomerRegistrationView(View):
    def get(self, request):
        form = CustomerRegisterationForm()
        return render(request, "app/customerregistration.html", locals())

    def post(self, request):
        form = CustomerRegisterationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Congratulations! User Registered Successfully")
        else:
            messages.warning(request, "Invalid Data")
        return render(request, "app/customerregistration.html", locals())
    
    class ProfileView(View):
        def get(self,request):
            form = CustomerProfileForm()
            return render(request,"app/profile.html",locals())


class ProfileView(View):
    def get(self,request):
        form = CustomerProfileForm()
        return render(request,"app/profile.html",locals())
    def post(self,request):
        form = CustomerProfileForm(request.POST)
        if form.is_valid():
            user = request.user
            name = form.cleaned_data['name']
            locality = form.cleaned_data['locality']
            city = form.cleaned_data['city']
            mobile = form.cleaned_data['mobile']
            state = form.cleaned_data['state']
            zipcode = form.cleaned_data['zipcode']

            reg = Customer(user=user,name=name,city=city,locality=locality,mobile=mobile,state=state,zipcode=zipcode)
            reg.save()
            messages.success(request,"Congratulation! Profile saved Successfully")
        else:
            messages.warning(request,"Enter Valid Data")

        return render(request,"app/profile.html",locals())
    
def address(request):
    add = Customer.objects.filter(user=request.user)
    return render(request,'app/address.html',locals())

class updateAddress(View):
    def get(self,request,pk):
        add = Customer.objects.get(pk=pk)
        form = CustomerProfileForm(instance=add)
        return render(request,"app/updateAddress.html",locals())
    def post(self,request,pk):
        form = CustomerProfileForm(request.POST)
        if form.is_valid():
            add = Customer.objects.get(pk=pk)
            add.name = form.cleaned_data["name"]
            add.locality = form.cleaned_data["locality"]
            add.city = form.cleaned_data["city"]
            add.mobile = form.cleaned_data["mobile"]
            add.state = form.cleaned_data["state"]
            add.zipcode = form.cleaned_data["zipcode"]
            add.save()
            messages.success(request, "Congratulations! Profile Update Successfully")
        else:
            messages.warning(request, "Invalid  data")
        return redirect("address")

class CategoryView(View):
    def get(self,request,val):
        product = Product.objects.filter(category=val)
        title = Product.objects.filter(category=val).values('title')
        return render(request,'app/category.html',locals())
    
class CategoryTitle(View):
    def get(self,request,val):
        product = Product.objects.filter(title=val)
        title = Product.objects.filter(category=product[0].category).values('title')
        return render(request,"app/category.html",locals())
    
class ProductDetail(View):
    def get(self,request,pk):
        product = Product.objects.get(pk=pk)
        return render(request,"app/productdetail.html",locals())
def add_to_cart(request):
    user=request.user
    product_id=request.GET.get('prod_id')
    product=Product.objects.get(id=product_id)
    Cart(user=user,product=product).save()
    return redirect("/cart")

def show_cart(request):
    user = request.user
    cart = Cart.objects.filter(user=user)
    amount = 0
    for p in cart:
        value = p.quantity * p.product.discounted_price
        amount = amount + value
    totalamount = amount + 40
    return render(request, 'app/addtocart.html',locals())

def plus_cart(request):
    prod_id = request.GET.get('prod_id')
    product = get_object_or_404(Product, id=prod_id)
    
    try:
        cart_item = Cart.objects.get(product=product, user=request.user)
        cart_item.quantity += 1
        cart_item.save()
        
        data = {
            'quantity': cart_item.quantity,
            'total_cost': cart_item.total_cost,
            'amount': calculate_cart_amount(request.user),
            'totalamount': calculate_total_amount(request.user)
        }
        return JsonResponse(data)
        
    except Cart.DoesNotExist:
        return JsonResponse({'error': 'Cart item not found'}, status=404)

def minus_cart(request):
    prod_id = request.GET.get('prod_id')
    product = get_object_or_404(Product, id=prod_id)
    
    try:
        cart_item = Cart.objects.get(product=product, user=request.user)
        if cart_item.quantity > 1:
            cart_item.quantity -= 1
            cart_item.save()
        else:
            cart_item.delete()

        data = {
            'quantity': cart_item.quantity if cart_item.quantity > 1 else 0,
            'total_cost': cart_item.total_cost if cart_item.quantity > 1 else 0,
            'amount': calculate_cart_amount(request.user),
            'totalamount': calculate_total_amount(request.user)
        }
        return JsonResponse(data)
        
    except Cart.DoesNotExist:
        return JsonResponse({'error': 'Cart item not found'}, status=404)

def remove_cart(request):
    prod_id = request.GET.get('prod_id')
    product = get_object_or_404(Product, id=prod_id)
    
    try:
        cart_item = Cart.objects.get(product=product, user=request.user)
        cart_item.delete()
        
        data = {
            'amount': calculate_cart_amount(request.user),
            'totalamount': calculate_total_amount(request.user),
            'success': True
        }
        return JsonResponse(data)
        
    except Cart.DoesNotExist:
        return JsonResponse({'error': 'Cart item not found'}, status=404)

# Utility functions to calculate total amounts
def calculate_cart_amount(user):
    cart_items = Cart.objects.filter(user=user)
    return sum(item.total_cost for item in cart_items)

def calculate_total_amount(user):
    amount = calculate_cart_amount(user)
    shipping = 50  
    return amount + shipping


class checkout(View):
    def get(self,request):
        user = request.user
        add = Customer.objects.filter(user=user)
        cart_items = Cart.objects.filter(user=user)
        final_amount = 0
        for a in cart_items:
            value = a.quantity * a.product.discounted_price
            final_amount = final_amount + value
        totalamount = final_amount + 40
        razoramount = int(totalamount * 100)
        client = razorpay.Client(auth=(settings.RAZOR_KEY_ID,settings.RAZOR_KEY_SECRET))
        data = {"amount":razoramount,"currency":"INR","receipt":"order_rcptid_12"}
        payment_response = client.order.create(data=data)
        print(payment_response)
        # {'id': 'order_OCH2eMzzCjjQcm', 'entity': 'order', 'amount': 504000, 'amount_paid': 0, 'amount_due': 504000, 'currency': 'INR', 'receipt': 'order_rcptid_12', 'offer_id': None, 'status': 'created', 'attempts': 0, 'notes': [], 'created_at': 1716104576}
        order_id = payment_response['id']
        order_status = payment_response['status']
        if order_status == 'created':
            payment = Payment(
                user=user,
                amount = totalamount,
                razorpay_order_id = order_id,
                razorpay_payment_status = order_status
            )
            payment.save()
        return render(request,'app/checkout.html',locals())

def payment_done(request):
    order_id=request.GET.get('order_id')
    payment_id = request.GET.get('payment_id')
    cust_id=request.GET.get('cust_id')
    # print("payment_done":oil = ",order_id," pid = ",payment_id," cid = ",cust_id")
    user = request.user
    # return redirect("orders")
    customer = Customer.objects.get(id=cust_id)
     # To update payment status and payment id
    payment = Payment.objects.get(razorpay_order_id=order_id)
    payment.paid = True
    payment.razorpay_payment_id = payment_id
    payment.save()
    # To save order details
    cart = Cart.objects.filter(user=user)
    for c in cart:
        OrderPlaced(user=user,customer=customer,product=c.product,quantity=c.quantity,payment=payment).save()
        c.delete()
    return redirect("orders")

def orders(request):
    order_placed=OrderPlaced.objects.filter(user=request.user)
    return render(request,'app/orders.html',locals())

