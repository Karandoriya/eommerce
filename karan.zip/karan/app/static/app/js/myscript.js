// Plus button functionality
$('.plus-cart').click(function () {
    var id = $(this).attr("pid").toString();
    var em1 = $(this).siblings('#quantity')[0];
    
    $.ajax({
        type: "GET",
        url: "/pluscart",
        data: {
            prod_id: id
        },
        success: function (data) {
            em1.innerText = data.quantity;
            document.getElementById("amount").innerText = data.amount;
            document.getElementById("totalamount").innerText = data.totalamount;
        }
    });
});

// Minus button functionality
$('.minus-cart').click(function () {
    var id = $(this).attr("pid").toString();
    var em1 = $(this).siblings('#quantity')[0];
    
    $.ajax({
        type: "GET",
        url: "/minuscart",
        data: {
            prod_id: id
        },
        success: function (data) {
            em1.innerText = data.quantity;
            document.getElementById("amount").innerText = data.amount;
            document.getElementById("totalamount").innerText = data.totalamount;
        }
    });
});

// Remove item functionality
$('.remove-cart').click(function () {
    var id = $(this).attr("pid").toString();
    
    $.ajax({
        type: "GET",
        url: "/removecart",
        data: {
            prod_id: id
        },
        success: function (data) {
            if (data.success) {
                $(this).closest('.cart-item').remove();  // Remove item from UI
            }
            document.getElementById("amount").innerText = data.amount;
            document.getElementById("totalamount").innerText = data.totalamount;
        }
    });
});
